<template>
  <schedule-table></schedule-table>
</template>

<script setup>
import ScheduleTable from './components/ScheduleTable/index.vue'
</script>

<style scoped lang="scss"></style>