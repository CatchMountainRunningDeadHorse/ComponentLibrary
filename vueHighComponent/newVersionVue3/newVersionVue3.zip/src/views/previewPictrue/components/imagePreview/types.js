const ARROW_DIRECTION = {
  LEFT: 'left',
  RIGHT: 'right'
}

const ZOOM = {
  IN: 'in',
  OUT: 'out'
}

export { ARROW_DIRECTION, ZOOM }
