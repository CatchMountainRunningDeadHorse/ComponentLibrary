export function findIndex(array, value) {
  return array.findIndex((item) => item === value)
}
