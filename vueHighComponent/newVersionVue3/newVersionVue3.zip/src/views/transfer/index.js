import Transfer from './components/transfer.vue'

export default {
  install(app) {
    app.component('Transfer', Transfer)
  }
}
