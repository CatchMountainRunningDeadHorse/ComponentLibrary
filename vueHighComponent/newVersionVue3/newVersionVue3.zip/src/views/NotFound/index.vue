<template>
  <h2>NOT FOUND 404</h2>
</template>

<script>
</script>

<style scoped>
h2 {
  text-align: center;
  margin: 20px 0;
}
</style>

